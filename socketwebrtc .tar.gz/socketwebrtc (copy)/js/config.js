/**
 * @author Amir Sanni <amirsanni@gmail.com>
 * @date 23-Dec-2016
 */

'use strict';


const appRoot = 'https://192.168.1.190/socketwebrtc/';
const wsUrl = 'wss://192.168.1.190'; //'ws://:8080';//use wss://localhost:8080/comm for secured connection
const spinnerClass = 'fa fa-spinner faa-spin animated';
